package com.example.demo.repository;

import com.example.demo.model.User;

import java.util.List;

public interface UserRepositoryInterface {


    List<User> getAllUsers();

    void addUser(String firstName, String lastName, String email);

    User findUserById(int idd);

    void deleteUser(Long id);


}
