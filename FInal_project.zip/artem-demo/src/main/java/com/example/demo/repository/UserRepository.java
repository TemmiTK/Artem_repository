package com.example.demo.repository;

import com.example.demo.exceptions.NameNotNumberException;
import com.example.demo.exceptions.UserCannotDeleteException;
import com.example.demo.model.User;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Repository
public class UserRepository implements UserRepositoryInterface {
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public UserRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {

        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }


    public List<User> getAllUsers() {
        String sql = "SELECT * FROM users";

        return namedParameterJdbcTemplate.query(sql, new RowMapper<User>() {
            @Override
            public User mapRow(ResultSet rs, int rowNum) throws SQLException {
                User user = new User();
                user.setId(rs.getLong("id"));
                user.setFirstName(rs.getString("first_name"));
                user.setLastName(rs.getString("last_name"));
                user.setEmail(rs.getString("email"));
                return user;
            }
        });
    }


    public void addUser(String firstName, String lastName, String email) {
        for (int i = 0; i < firstName.length(); i++) {
            if (Character.isDigit(firstName.charAt(i))){
                throw new NameNotNumberException("Name can not contain numbers");
            }
        }
        String sql = "INSERT INTO users (first_name, last_name, email) VALUES (:firstName, :lastName, :email)";
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("firstName", firstName);
        params.addValue("lastName", lastName);
        params.addValue("email", email);
        namedParameterJdbcTemplate.update(sql, params);
    }


    public User findUserById(int id) {
        String sql = "SELECT * FROM users WHERE id = :id";
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("id", id);
        try {
            return namedParameterJdbcTemplate.queryForObject(sql, parameters, (rs, rowNum) -> {
                User user = new User();
                user.setId(rs.getLong("id"));
                user.setFirstName(rs.getString("first_name"));
                user.setLastName(rs.getString("last_name"));
                user.setEmail(rs.getString("email"));
                return user;
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }


    public void deleteUser(Long id) {
            String sql = "DELETE FROM users WHERE id = :id";
            MapSqlParameterSource map = new MapSqlParameterSource();
            map.addValue("id", id);
            int rowAffected = namedParameterJdbcTemplate.update(sql, map);
            if (rowAffected == 0) {
                throw new UserCannotDeleteException("User can not be deleted with this id bro");

            }
    }
}


