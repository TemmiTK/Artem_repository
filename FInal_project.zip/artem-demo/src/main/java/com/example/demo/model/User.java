package com.example.demo.model;

public class User {
    private Long id;
    private String firstNameee;  // Теперь это firstName
    private String lastName;   // И это lastName
    private String email;

    // Конструкторы, геттеры и сеттеры

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstNameee;
    }

    public void setFirstName(String firstName) {
        this.firstNameee = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
