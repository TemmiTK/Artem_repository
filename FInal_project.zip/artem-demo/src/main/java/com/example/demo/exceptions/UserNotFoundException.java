package com.example.demo.exceptions;

public class UserNotFoundException extends RuntimeException {
    private String massage;
    public UserNotFoundException(String message) {
        this.massage = message;
    }
}
