package com.example.demo.exceptions;

import com.example.demo.model.User;

public class UserCannotDeleteException  extends RuntimeException{
    public UserCannotDeleteException(String massage){
        super(massage);
    }

}
