package com.example.demo.service;

import com.example.demo.exceptions.UserNotFoundException;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserService {


    private UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public List<User> getUsers() {
        return userRepository.getAllUsers();
    }

    public void createUser(String firstName, String lastName, String email) {
        userRepository.addUser(firstName, lastName, email);
    }
    public User findUserbyid(int id){

        return userRepository.findUserById(id);
    }

    public void removeUser(Long id) {
        userRepository.deleteUser(id);
    }
}




