package com.example.demo.controller;



import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@RequestMapping("/api/users")
@RestController
public class UserController {

    private UserService userService;
    @Autowired
    public  UserController(UserService userService){
        this.userService = userService;
    }


    @GetMapping
    public List<User> getAllUsers() {
        return userService.getUsers();
    }
    @GetMapping("/{id}")
    public User findUserbyid(@PathVariable int id) {
        return userService.findUserbyid(id);
    }



    @PostMapping
    public void createUser(@RequestBody User user) {
        userService.createUser(user.getFirstName(), user.getLastName(), user.getEmail());
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.removeUser(id);
    }




}


