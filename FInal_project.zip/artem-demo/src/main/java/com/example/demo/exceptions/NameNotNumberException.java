package com.example.demo.exceptions;

public class NameNotNumberException extends RuntimeException{
    public NameNotNumberException(String massage){
        super(massage);
    }
}
