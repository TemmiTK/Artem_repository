package com.example.service;

import com.example.model.User;
import com.example.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Получить всех пользователей
    public List<User> getAllUsers() {
        return userRepository.getAllUsers();
    }

    // Получить пользователя по ID
    public Optional<User> getUserById(Long id) {
        return userRepository.getUserById(id);
    }

    // Создать нового пользователя
    public int createUser(User user) {
        return userRepository.createUser(user);
    }

    // Обновить пользователя
    public int updateUser(Long id, User user) {
        return userRepository.updateUser(id, user);
    }

    // Удалить пользователя
    public int deleteUser(Long id) {
        return userRepository.deleteUser(id);
    }
}


