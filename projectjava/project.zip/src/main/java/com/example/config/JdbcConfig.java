package com.example.config;

public class JdbcConfig {
}
